const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');

const app = express();
const port = 5000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// MySQL Connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Vijayan129#',
    database: 'registrationdb'
});

db.connect((err) => {
    if (err) throw err;
    console.log('Connected to MySQL Database');
});

// Serve HTML form
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

// Handle form submission
app.post('/register', (req, res) => {
    const { name, email, gender, age, dob, address, phone } = req.body;

    const sql = 'INSERT INTO customer (name, email, gender, age, dob, address, phone) VALUES (?, ?, ?, ?, ?, ?, ?)';
    db.query(sql, [name, email, gender, age, dob, address, phone], (err, result) => {
        if (err) throw err;
        res.send('Registration successful!');
    });
});

// Start server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
